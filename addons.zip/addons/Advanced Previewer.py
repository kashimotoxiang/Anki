# -*- coding: utf-8 -*-

"""
Anki Add-on: Advanced Previewer

Entry point for the add-on into Anki

Please don't edit this if you don't know what you're doing.

Copyright: (c) Glutanimate 2016-2017
Original add-on commissioned by: Alexander A.
Card reviewing support implemented on a commission by <name withheld>

License: GNU AGPL, version 3 or later; https://www.gnu.org/licenses/agpl-3.0.en.html
""" 

import advanced_previewer.main