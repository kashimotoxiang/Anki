# Keep this file short to make maintenance cleaner
import hierarchical_tags_addon.hierarchical_tags
