from docs._version import __version__
