def escape_md_section_override(text, snob=False):
    """
    Disable the default escaping of Markdown-sensitive characters.
    """
    return text
