# This file imports Image Occlusion Enhanced into Anki
# Please don't edit this if you don't know what you're doing.

import image_occlusion_enhanced.main
