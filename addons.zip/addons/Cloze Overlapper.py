# -*- coding: utf-8 -*-

"""
Anki Add-on: Cloze Deletion Overlapper

Entry point for the add-on into Anki

Please don't edit this if you don't know what you're doing.

Copyright: (c) Glutanimate 2016-2017
License: GNU GPL, version 3 or later; http://www.gnu.org/copyleft/gpl.html

""" 

import cloze_overlapper.main