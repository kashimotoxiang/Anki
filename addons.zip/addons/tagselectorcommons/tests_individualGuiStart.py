﻿#-------------------------------------------------------------------------------
# Name:        TagSelector                  # Author:      DarkTrick
# Copyright:   (c) DarkTrick since 2016     # Licence:     CC-BY
#-------------------------------------------------------------------------------



from tests_emptyWindow import *
from Empty import *
from tagselectorgui import *
from aqtEditorMOCK import *
# for making a resizable docking-area
from QtAdditions import WidgetSizeable

class LineEditString(QtGui.QLineEdit):
    """we need this, as ankis edit-fields also return a string, rather than a
        QString!
    """
    def text(self):
        return unicode(super(LineEditString, self).text(), "utf-8")

def openAddCardsDialog():
    ui = setupAddCardsGui()

    # make necessary gui elements from anki available
    ui.editor = EditorMOCK()
    ui.editor.tags = LineEditString(ui.verticalLayoutWidget)
    ui.editor.tags.setObjectName("tags")
    ui.verticalLayout.addWidget(ui.editor.tags)

    dockWidget = TSDockWidget(ui)
    dockWidget.setObjectName("dockWidget2")

    tsGui = TagSelectorGui(ui,ui.editor,170)
    tsGui.addTagSelectorItems(3)
    dockWidget.setWidget(tsGui)

    ui.addDockWidget(QtCore.Qt.DockWidgetArea(2), dockWidget)

def main():
    app = setupApp(sys.argv)
    #openAddCardsDialog()

    uiMainWindow = setupButtonGui()
    QtCore.QObject.connect(uiMainWindow.pushButton, QtCore.SIGNAL(("clicked()")), openAddCardsDialog)


    # add TS gui
    ##tsGui = TagSelectorGui(ui,ui.editor,7,10,170)

    # finally start the testgui
    app.exec_()



if __name__ == '__main__':
    import sys
    main()
