#-------------------------------------------------------------------------------
# Name:        TagSelector                  # Author:      DarkTrick
# Copyright:   (c) DarkTrick since 2016     # Licence:     CC-BY
#-------------------------------------------------------------------------------


from PyQt4 import QtCore, QtGui
import sys
from tagselectorgui import TSDockWidget

"""
    creates an empty main window, that we an use.
    To inject to the gui, an object passed to startmain must
    implement a run(ui) method

"""


try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class EmptyWindow(QtGui.QMainWindow):
    def __init__(self):
        QtGui.QMainWindow.__init__(self,None)

    def setupUi(self):
        self.centralwidget = QtGui.QWidget(self)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
    pass

class WindowWithButton(EmptyWindow):
    pass
    def setupUi(self):
        super(WindowWithButton,self).setupUi()

        self.resize(500, 400)

        self.setObjectName(_fromUtf8("Buttonwindow"))
        #self.pushButton = QtGui.QPushButton(self.centralwidget)
        #self.pushButton.setObjectName(_fromUtf8("openAddCards"))
        #self.pushButton.setText("openAddCards")
        self.customSetup()

    def customSetup(self):
        """ here goes the code for changing the gui"""

        MainWindow = self
        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 420, 18))
        self.menubar.setObjectName(_fromUtf8("menubar"))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(MainWindow)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        MainWindow.setStatusBar(self.statusbar)

        self.dockWidget = TSDockWidget(MainWindow)
        self.dockWidget.setWindowTitle("aaadfsd")
        self.dockWidget.specialInit()

        self.dockWidget.setAllowedAreas(QtCore.Qt.BottomDockWidgetArea|QtCore.Qt.LeftDockWidgetArea|QtCore.Qt.RightDockWidgetArea)
        self.dockWidget.setObjectName(_fromUtf8("dockWidget"))
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName(_fromUtf8("dockWidgetContents"))
        self.pushButton = QtGui.QPushButton(self.dockWidgetContents)
        self.pushButton.setGeometry(QtCore.QRect(0, 0, 89, 27))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.dockWidget.setWidget(self.dockWidgetContents)
        MainWindow.addDockWidget(QtCore.Qt.DockWidgetArea(2), self.dockWidget)

        pass




class AddCardsWindow(EmptyWindow):


    def setupUi(self):
        super(AddCardsWindow,self).setupUi()

        self.setObjectName(_fromUtf8("self"))

        # set size
        self.resize(500, 400)

        #
        #  _____________________________________
        # |     horizontal                      |
        # |   ___________     _______________   |
        # |  | vertical |    |   vertical   |   |
        # |  |  normal  |    |  tagSelector |   |
        # |  |__________|    |   GUI        |   |
        # |                  |______________|   |
        # |                                     |
        # |_____________________________________|

        # horizontal
        self.horizontalLayoutWidget = QtGui.QWidget(self.centralwidget)
        self.horizontalLayoutWidget.setGeometry(QtCore.QRect(0, 0, 301, 200))
        self.horizontalLayoutWidget.setObjectName(_fromUtf8("horizontalLayoutWidget"))
        self.horizontalLayout = QtGui.QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setMargin(0)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))

        # vertical normal
        self.verticalLayoutWidget = QtGui.QWidget(self.horizontalLayoutWidget)
        self.verticalLayoutWidget.setObjectName(_fromUtf8("verticalLayoutWidget"))
        self.verticalLayout = QtGui.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.horizontalLayout.addWidget(self.verticalLayoutWidget)

        self.lineEdit = QtGui.QLineEdit(self.verticalLayoutWidget)
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.verticalLayout.addWidget(self.lineEdit)


        self.pushButton = QtGui.QPushButton(self.verticalLayoutWidget)
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.pushButton.setText("Testbutton")
        self.verticalLayout.addWidget(self.pushButton)

        self.setCentralWidget(self.centralwidget)

        self.menubar = QtGui.QMenuBar(self)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 552, 21))
        self.menubar.setObjectName(_fromUtf8("menubar"))

        self.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(self)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        self.setStatusBar(self.statusbar)

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)

    def retranslateUi(self):
        self.setWindowTitle(QtGui.QApplication.translate("MainWindow", "MainWindow", None, QtGui.QApplication.UnicodeUTF8))

""" return gui"""
def setupAddCardsGui():
    ui = AddCardsWindow()
    ui.setupUi()
    ui.show()

    return ui

""" return gui"""
def setupButtonGui():
    ui = WindowWithButton()
    ui.setupUi()
    ui.show()

    return ui

""" starts the app"""
def setupApp(argv):
    app = QtGui.QApplication(argv)

    return app

def startmain():
    app = QtGui.QApplication(sys.argv)
    ui = Ui_MainWindow()
    ui.setupUi()
    ui.show()
    app.exec_()


if __name__ == "__main__":
    import sys
    app = setupApp(sys.argv)
    ui = WindowWithButton()
    #ui = EmptyWindow()
    ui.setupUi()
    ui.show()
    app.exec_()