#-------------------------------------------------------------------------------
# Name:        TagSelector                  # Author:      DarkTrick
# Copyright:   (c) DarkTrick since 2016     # Licence:     CC-BY
#-------------------------------------------------------------------------------

from PyQt4 import QtCore, QtGui


class LineEditReturnsString(QtGui.QLineEdit):

    def text(self):
        return (super(LineEditReturnsString,self).text())