#-------------------------------------------------------------------------------
# Name:        TagSelector                  # Author:      DarkTrick
# Copyright:   (c) DarkTrick since 2016     # Licence:     CC-BY
#-------------------------------------------------------------------------------

class EditorMOCK:

    def __init__(self):
        pass

    def saveTags(self):
        # just do nothing
        pass