#-------------------------------------------------------------------------------
# Name:        TagSelector                  # Author:      DarkTrick
# Copyright:   (c) DarkTrick since 2016     # Licence:     CC-BY
#-------------------------------------------------------------------------------


import sys
from PyQt4 import QtCore, QtGui
from dialogWithDock import *



def main():
    app = QtGui.QApplication(sys.argv)
    dialog = QtGui.QDialog()
    dialog.resize(250, 150)

    form = Ui_Dialog()
    form.setupUi(dialog)
    dialog.show()

    # -------------- manipulation --------------------

    mainWindow = QtGui.QMainWindow()

    mainWindow.centralwidget = QtGui.QWidget(mainWindow)
    mainWindow.setCentralWidget(mainWindow.centralwidget)

    dockWidget = QtGui.QDockWidget(mainWindow)
    dockWidget.setObjectName("dockWidget2")
    dockWidgetContents = QtGui.QWidget()
    dockWidgetContents.setObjectName("dockWidgetContents2")
    dockWidget.setWidget(dockWidgetContents)

    pushButton = QtGui.QPushButton(dockWidgetContents)
    pushButton.setObjectName(("pushButton"))
    pushButton.setText("Testbutton")

    form.horizontalLayout.addWidget(mainWindow)

    # ------------------------------------------------

    app.exec_()
    pass

if __name__ == '__main__':
    main()
