# -*- coding: utf-8 -*-
# wildcardField 2.0, an Anki addon to 
# - enable searching for field contents exactly matching an expression without limiting the search to a specific field.
# - enable searching for words: ;dog; finds the word "dog" anywhere within a field but not "dogma". ;dog finds dogma, dog; finds bulldog
# License: GNU AGPL, version 3 or later; http://www.gnu.org/licenses/agpl.html
# Modified fron Anki 2.0.28 source code in 2014 by Teemu Pudas
# Anki is Copyright: Damien Elmes <anki@ichi2.net> 
# (I include his email address because that's how it is in the original copyright notice in the Anki source code.
# Don't contact him about bugs in this addon (they're not his fault), use http://anki.tenderapp.com/discussions/add-ons instead)

from anki.find import Finder
from anki.hooks import wrap
from anki.utils import ids2str, splitFields
import re
import sre_constants

def make_regex(val, separator=False):
	dot = "." if not separator else "[^\x1f]"
	if val.startswith(";"):
		val = "*" + val
	if val.endswith(";"):
		val += "*"
	regex = re.escape(val.replace("*", "%")).replace("\\;", "(\\b|\\;)").replace("\\_", dot).replace("\\%", dot + "*")
	start = "(^|\x1f)" if separator else "^"
	end = "($|\x1f)" if separator else "$"
	return "(?ui)" + start + regex + end
	
def like_exp(val):
	val = val.replace("*", "%")
	val = val.replace(";", "%")
	val = "%" + val + "%"
	return re.sub("%+", "%", val)
	
def _findField(self, field, val, _old):
	if field != "*" and ";" not in val:
		return _old(self, field, val)
		
	regex = make_regex(val, field=="*")
	val = like_exp(val)
	query = """
select id, mid, flds from notes
where flds like ? escape '\\'"""
	# find models that have that field
	mods = {}
	if field != "*":
		for m in self.col.models.all():
			for f in m['flds']:
				if f['name'].lower() == field:
					mods[str(m['id'])] = (m, f['ord'])
		if not mods:
			# nothing has that field
			return "0"
		query = query.replace("where", "where mid in %s and" % (ids2str(mods.keys())))
	# gather nids
	
	nids = []
	for (id, mid, flds) in self.col.db.execute(query, val):
		if mods:
			ord = mods[str(mid)][1]
			flds = splitFields(flds)[ord]
		try: 
			if re.search(regex, flds):
				nids.append(id)
		except sre_constants.error:
			return "0"
	if not nids:
		return "0"
	return "n.id in %s" % ids2str(nids)
	
def _findText(self, val, args, _old):
	if ";" not in val:
		return _old(self, val, args)
	if not val.startswith(";"):
		val = "*" + val
	if not val.endswith(";"):
		val = val + "*"
	
	return self._findField("*", val)
	
Finder._findField = wrap(Finder._findField, _findField, "around")
Finder._findText = wrap(Finder._findText, _findText, "around")