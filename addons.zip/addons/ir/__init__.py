# -*- coding: utf-8 -*-

from __future__ import unicode_literals

from aqt import mw

import ir.main

mw.readingManager = ir.main.ReadingManager()
