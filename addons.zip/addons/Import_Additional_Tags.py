# Import Additional Tags
# Author: Paul Hueber <phueber@gmx.de>
# 
# This addon adds a new target field for csv field mapping to import
# additional tags to existing notes.

# Copyright: Damien Elmes <anki@ichi2.net>
# License: GNU AGPL, version 3 or later; http://www.gnu.org/licenses/agpl.html

# dependencies of patched code
import cgi
from aqt.qt import *
from anki.errors import *
import aqt.forms
from anki.lang import _, ngettext
from anki.utils import fieldChecksum, timestampID, \
    joinFields, intTime, splitFields

# overwrite member functions
from anki.importing.noteimp import NoteImporter
from aqt.importing import ChangeMap, ImportDialog

def importNotes(self, notes):
	"Convert each card into a note, apply attributes and add to col."
	assert self.mappingOk()
	# note whether tags are mapped
	self._tagsMapped = False
	self._addtagsMapped = False
	for f in self.mapping:
		if f == "_tags":
			self._tagsMapped = True
		elif f == "_addtags":
			self._tagsMapped = True
			self._addtagsMapped = True
	# gather checks for duplicate comparison
	csums = {}
	for csum, id in self.col.db.execute(
		"select csum, id from notes where mid = ?", self.model['id']):
		if csum in csums:
			csums[csum].append(id)
		else:
			csums[csum] = [id]
	firsts = {}
	fld0idx = self.mapping.index(self.model['flds'][0]['name'])
	self._fmap = self.col.models.fieldMap(self.model)
	self._nextID = timestampID(self.col.db, "notes")
	# loop through the notes
	updates = []
	new = []
	self._ids = []
	self._cards = []
	self._emptyNotes = False
	for n in notes:
		if not self.allowHTML:
			for c in range(len(n.fields)):
				n.fields[c] = cgi.escape(n.fields[c])
		fld0 = n.fields[fld0idx]
		csum = fieldChecksum(fld0)
		# first field must exist
		if not fld0:
			self.log.append(_("Empty first field: %s") %
							" ".join(n.fields))
			continue
		# earlier in import?
		if fld0 in firsts and self.importMode != 2:
			# duplicates in source file; log and ignore
			self.log.append(_("Appeared twice in file: %s") %
							fld0)
			continue
		firsts[fld0] = True
		# already exists?
		found = False
		if csum in csums:
			# csum is not a guarantee; have to check
			for id in csums[csum]:
				flds = self.col.db.scalar(
					"select flds from notes where id = ?", id)
				sflds = splitFields(flds)
				if fld0 == sflds[0]:
					# duplicate
					found = True
					if self.importMode == 0:
						data = self.updateData(n, id, sflds)
						if data:
							updates.append(data)
							found = True
						break
					elif self.importMode == 2:
						# allow duplicates in this case
						found = False
		# newly add
		if not found:
			data = self.newData(n)
			if data:
				new.append(data)
				# note that we've seen this note once already
				firsts[fld0] = True
	self.addNew(new)
	self.addUpdates(updates)
	self.col.updateFieldCache(self._ids)
	# generate cards
	if self.col.genCards(self._ids):
		self.log.insert(0, _(
			"Empty cards found. Please run Tools>Maintenance>Empty Cards."))
	# apply scheduling updates
	self.updateCards()
	# make sure to update sflds, etc
	part1 = ngettext("%d note added", "%d notes added", len(new)) % len(new)
	part2 = ngettext("%d note updated", "%d notes updated", self.updateCount) % self.updateCount
	self.log.append("%s, %s." % (part1, part2))
	if self._emptyNotes:
		self.log.append(_("""\
One or more notes were not imported, because they didn't generate any cards. \
This can happen when you have empty fields or when you have not mapped the \
content in the text file to the correct fields."""))
	self.total = len(self._ids)

def processFields(self, note, fields=None):
	if not fields:
		fields = [""]*len(self.model['flds'])
	for c, f in enumerate(self.mapping):
		if not f:
			continue
		elif f == "_tags":
			note.tags.extend(self.col.tags.split(note.fields[c]))
		elif f == "_addtags":
			note.tags.extend(self.col.tags.split(note.fields[c]))
		else:
			sidx = self._fmap[f][0]
			fields[sidx] = note.fields[c]
	note.fieldsStr = joinFields(fields)
	ords = self.col.models.availOrds(self.model, note.fieldsStr)
	if not ords:
		self._emptyNotes = True
	return ords

_updateData = NoteImporter.updateData
def updateData(self, n, id, sflds):
	if self._addtagsMapped:
		oldtags = self.col.db.first("select tags from notes where id = ?",id)
		oldtags = self.col.tags.split(oldtags[0])
		n.tags.extend(oldtags)
		n.tags = self.col.tags.canonify(n.tags)
	return _updateData(self, n, id, sflds)

def accept(self):
	row = self.frm.fields.currentRow()
	if row < len(self.model['flds']):
		self.field = self.model['flds'][row]['name']
	elif row == self.frm.fields.count() - 3:
		self.field = "_tags"
	elif row == self.frm.fields.count() - 2:
		self.field = "_addtags"
	else:
		self.field = None
	QDialog.accept(self)

def ChangeMap_init(self, mw, model, current):
	QDialog.__init__(self, mw, Qt.Window)
	self.mw = mw
	self.model = model
	self.frm = aqt.forms.changemap.Ui_ChangeMap()
	self.frm.setupUi(self)
	n = 0
	setCurrent = False
	for field in self.model['flds']:
		item = QListWidgetItem(_("Map to %s") % field['name'])
		self.frm.fields.addItem(item)
		if current == field['name']:
			setCurrent = True
			self.frm.fields.setCurrentRow(n)
		n += 1
	self.frm.fields.addItem(QListWidgetItem(_("Map to Tags")))
	self.frm.fields.addItem(QListWidgetItem("Add to Tags"))
	self.frm.fields.addItem(QListWidgetItem(_("Discard field")))
	if not setCurrent:
		if current == "_tags" or current == "_addtags":
			self.frm.fields.setCurrentRow(n)
		else:
			self.frm.fields.setCurrentRow(n+1)
	self.field = None

def showMapping(self, keepMapping=False, hook=None):
	if hook:
		hook()
	if not keepMapping:
		self.mapping = self.importer.mapping
	self.frm.mappingGroup.show()
	assert self.importer.fields()
	# set up the mapping grid
	if self.mapwidget:
		self.mapbox.removeWidget(self.mapwidget)
		self.mapwidget.deleteLater()
	self.mapwidget = QWidget()
	self.mapbox.addWidget(self.mapwidget)
	self.grid = QGridLayout(self.mapwidget)
	self.mapwidget.setLayout(self.grid)
	self.grid.setMargin(3)
	self.grid.setSpacing(6)
	fields = self.importer.fields()
	for num in range(len(self.mapping)):
		text = _("Field <b>%d</b> of file is:") % (num + 1)
		self.grid.addWidget(QLabel(text), num, 0)
		if self.mapping[num] == "_tags":
			text = _("mapped to <b>Tags</b>")
		elif self.mapping[num] == "_addtags":
			text = "mapped to <b>additional Tags</b>"
		elif self.mapping[num]:
			text = _("mapped to <b>%s</b>") % self.mapping[num]
		else:
			text = _("<ignored>")
		self.grid.addWidget(QLabel(text), num, 1)
		button = QPushButton(_("Change"))
		self.grid.addWidget(button, num, 2)
		self.connect(button, SIGNAL("clicked()"),
					 lambda s=self,n=num: s.changeMappingNum(n))

# overwrite functions
NoteImporter.importNotes = importNotes
NoteImporter.processFields = processFields
NoteImporter.updateData = updateData
ChangeMap.accept = accept
ChangeMap.__init__ = ChangeMap_init
ImportDialog.showMapping = showMapping
